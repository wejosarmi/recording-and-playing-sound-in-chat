import 'package:permission_handler/permission_handler.dart';
Future<bool> requstPermission(Permission permission) async {
  if (await permission.isGranted) {
    return true;
  } else {
    var res = await permission.request();
    if (res == PermissionStatus.granted) {
      return true;
    } else {
      return false;
    }
  }
}