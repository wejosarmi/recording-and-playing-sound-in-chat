import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'cubit.dart';
import 'state.dart';
const double BUBBLE_RADIUS_AUDIO = 16;
class AudioPlayerCubitPage extends StatefulWidget {
  void Function(Duration value)? onSeekChanged;
  final void Function()? onPlayPauseButtonClick;
  final bool isPlaying;
  final bool isPause;
  final  String url;
  final int index;
  Duration? duration;
  Duration? position;


  final bool? isLoading;
  final double bubbleRadius;
  final bool isSender;
  final Color color;
  final bool tail;
  final bool sent;
  final bool delivered;
  final bool seen;
  final TextStyle textStyle;
  AudioPlayerCubitPage({
    Key? key,

      this.onSeekChanged,
     this.onPlayPauseButtonClick,
    required this.isPlaying,
    required this.isPause,
    required this.url,
    required this.index,
    this.duration,
    this.position,
    this.isLoading,
    this.bubbleRadius = BUBBLE_RADIUS_AUDIO,
    this.isSender = true,
    this.color = Colors.white70,
    this.tail = true,
    this.sent = false,
    this.delivered = false,
    this.seen = false,
    this.textStyle = const TextStyle(
      color: Colors.black87,
      fontSize: 12,
    ),
  }) : super(key: key);

  @override
  State<AudioPlayerCubitPage> createState() => _AudioPlayerCubitPageState();
}
class _AudioPlayerCubitPageState extends State<AudioPlayerCubitPage> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AudioPlayerCubit(isPlaying:widget.isPlaying,
      isPause: widget.isPause,
      isLoading: widget.isLoading,
        duration: widget.duration!,
        position: widget.duration!,
        url1: widget.url,
        onSeekChanged: widget.onSeekChanged,
        onPlayPauseButtonClick: widget.onPlayPauseButtonClick
      ),
      child: Builder(builder: (context) => _buildPage(context)),
    );
  }

  Widget _buildPage(BuildContext context) {
    ValueNotifier<Duration> currentdu = ValueNotifier(Duration.zero);
    bool stateTick = true;
    Icon? stateIcon;
    if (widget.sent) {
      stateTick = true;
      stateIcon = const Icon(
        Icons.done,
        size: 18,
        color: Color(0xFF97AD8E),
      );
    }
    if (widget.delivered) {
      stateTick = true;
      stateIcon = const Icon(
        Icons.done_all,
        size: 18,
        color: Color(0xFF97AD8E),
      );
    }
    if (widget.seen) {
      stateTick = true;
      stateIcon = const Icon(
        Icons.done_all,
        size: 18,
        color: Color(0xFF92DEDA),
      );
    }

    final cubit = BlocProvider.of<AudioPlayerCubit>(context);
    return Container(
      child: Row(
        children: <Widget>[
          widget.isSender
              ? const Expanded(
            child: SizedBox(
              width: 5,
            ),
          )
              : Container(),
          Container(
            color: Colors.transparent,
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * .8,
                maxHeight: 70),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              child: Container(
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(widget.bubbleRadius),
                    topRight: Radius.circular(widget.bubbleRadius),
                    bottomLeft: Radius.circular(widget.tail
                        ? widget.isSender
                        ? widget.bubbleRadius
                        : 0
                        : BUBBLE_RADIUS_AUDIO),
                    bottomRight: Radius.circular(widget.tail
                        ? widget.isSender
                        ? 0
                        : widget.bubbleRadius
                        : BUBBLE_RADIUS_AUDIO),
                  ),
                ),
                child: Stack(
                        children: [
                          Row(
                            children: [
                              RawMaterialButton(
                                onPressed: (){
                                  if(context.read<AudioPlayerCubit>().state is AudioPlayerStarted){
                                    context.read<AudioPlayerCubit>().stopPlay();
                                  }
                                  context.read<AudioPlayerCubit>().startPlay(url:widget.url);
                                },
                                // soundProvider.togglePlaying();


                                elevation: 1.0,
                                fillColor: Colors.white,
                                child:
                                widget.isPlaying==false
                                    ? const Icon(
                                  Icons.play_arrow,
                                  //   Icons.pause, ///~~///////////////
                                  size: 30.0,
                                )
                                    :    widget.isLoading!
                                    ? CircularProgressIndicator()
                                    :    widget.isPause==true
                                    ? const Icon(
                                  Icons.play_arrow, ///////////////////,
                                  size: 30.0,
                                  color: Colors.amber,
                                )
                                    : const Icon(Icons.pause,
                                    size: 30.0, color: Colors.red),
                                padding: const EdgeInsets.all(0.0),
                                shape: const CircleBorder(),
                              ),
                              Expanded(
                                child: ValueListenableBuilder<Duration>(
                                    valueListenable:context.read<AudioPlayerCubit>().currentDuration,

                                    builder: (_,  value, __) {
                                      return BlocBuilder<AudioPlayerCubit, AudioPlayerCubitState>(
                                      builder: (_, AudioPlayerCubitState state) {
                                          return Slider(
                                            min: 0,
                                            max: widget.duration!.inSeconds.toDouble()==null?0.0:widget.duration!.inSeconds.toDouble(),
                                            //max: soundProvider.duration.inSeconds.toDouble()==null?0.0:soundProvider.duration.inSeconds.toDouble(),
                                            value:widget.position==null?0.0:widget.position!.inSeconds.toDouble(),
                                            onChanged: (value) {



                                              setState(() {
                                                widget.position = widget.position!;
                                                final position = value * widget.duration!.inMicroseconds.toDouble();
                              widget.onSeekChanged!( Duration(milliseconds: position.round()));

                                                widget.position = value as Duration?;
                                              });


                                            },
                                          );
                                        }
                                      );}
                                ),
                              ),
                            ],
                          ),
                          //     Text("Index "+widget.url.toString()),
                          Positioned(
                            bottom: 5,
                            right: 25,
                            child: ValueListenableBuilder<Duration?>(
                              valueListenable:context.read<AudioPlayerCubit>().currentDuration,
                              builder: (_, value, __) {
                                // double d = value!.inSeconds.toDouble();

                                return BlocConsumer<AudioPlayerCubit, AudioPlayerCubitState>(
  listener: (context, state) {
    print("ssssssssssssssssssssssssssss "+state.toString());
  },
  builder: (context, state) {
    return Container(
                                  child: Column(
                                    children: [
                                      //  widget.duration ==null ?Text(dd.toString()):
                                      Text(
                                        '${audioTimer( context.read<AudioPlayerCubit>().duration.inSeconds.toDouble(),  context.read<AudioPlayerCubit>().position.inSeconds.toDouble())}',
                                      ),
                                    ],
                                  ),
                                );
  },
);
                              },
                            ),
                          ),
                          stateIcon != null && stateTick
                              ? Positioned(
                            bottom: 4,
                            right: 6,
                            child: stateIcon,
                          )
                              : SizedBox(
                            width: 1,
                          ),
                        ],
                      )

                  ),
                ),
              )
    ]
      )
    );


  }
String audioTimer(final duration, double position) {
  return '${(duration ~/ 60).toInt()}:${(duration % 60).toInt().toString().padLeft(2, '0')}/${position ~/ 60}:${(position % 60).toInt().toString().padLeft(2, '0')}';
}
}


