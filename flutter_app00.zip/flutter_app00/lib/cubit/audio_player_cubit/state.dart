


abstract class AudioPlayerCubitState {}

 class AudioPlayerReady extends AudioPlayerCubitState {
   @override
   String toString() {
     return 'RecordAudioReady';
   }
  }

class AudioPlayerStarted extends AudioPlayerCubitState {
  @override
  String toString() {
    return 'AudioPlayerReady';
  }
}
class AudioPlayerClosed extends AudioPlayerCubitState {
  @override
  String toString() {
    return 'AudioPlayerClosed';
  }
}
