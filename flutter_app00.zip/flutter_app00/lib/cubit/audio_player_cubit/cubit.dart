import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import "package:path/path.dart" as pp;
import '../../utils/customPremission.dart';
import 'state.dart';

class AudioPlayerCubit extends Cubit<AudioPlayerCubitState> {
  void Function(Duration value) ?onSeekChanged;
  final void Function()? onPlayPauseButtonClick;
  AudioPlayer? audioPlayer;
  Duration _duration = Duration();
  Duration _position=Duration();
 String? url1;
  bool? isPlaying=false;
  bool? isLoading=false;
  bool? isPause=false;
  Duration get duration => _duration;
  Duration get position => _position;
  ValueNotifier<Duration> currentDuration = ValueNotifier(Duration.zero);
  /////////////////////////////////////////////////
  StreamSubscription? _durationSubscription;
  StreamSubscription? _positionSubscription;
  StreamSubscription? _playerCompleteSubscription;
  StreamSubscription? _playerErrorSubscription;
  StreamSubscription? _playerStateSubscription;
  StreamSubscription? _playerSeekSubscription;
  AudioPlayerCubit({this.isPlaying,
    this.isPause,
    this.isLoading,
     duration,
     this.url1,
     position,
  this.onSeekChanged,
    this.onPlayPauseButtonClick
  }) : super(AudioPlayerReady()) {
    audioPlayer=AudioPlayer();

    _positionSubscription =
        audioPlayer!.onAudioPositionChanged.listen(( p) {
          position = p;

        });


  }
  void toggleRecord({required bool canRecord}) {
    emit(canRecord ? AudioPlayerReady() : AudioPlayerClosed());
  }
  void getDuration({required AudioPlayer player}) async{
    player.onDurationChanged.listen((d) {
      _duration = d;
      currentDuration.value=_duration;
    });
  }
  void getPosition({required AudioPlayer player}) async{
    try {

          player.onAudioPositionChanged.listen(( p) {
            _position = p;


          });
      emit(AudioPlayerStarted());
    }catch(e){
      emit(AudioPlayerStarted());
      emit(AudioPlayerReady());
    }
  }
  Future<void>stopPlay() async{
    try{
      await  audioPlayer!.stop();
      emit(AudioPlayerStarted());
    }catch(e){
      emit(AudioPlayerReady());
    }
  }
  Future<void>startPlay({required String url})async {
    try{
    //  currentDuration.value = Duration.zero;

      await audioPlayer!.play( "file://" +url, isLocal: true, stayAwake: true,);
      getDuration(player: audioPlayer!);
      getPosition(player: audioPlayer!);
      emit(AudioPlayerStarted());
    }catch(e){
      emit(AudioPlayerReady());
    }
  }
  Future<void>pusedPlay() async{
    try{
      await  audioPlayer!.pause();
      emit(AudioPlayerStarted());
    }catch(e){
      emit(AudioPlayerReady());
    }
  }
  Future<void>resumPlay() async{
    try{
      await  audioPlayer!.resume();
      emit(AudioPlayerStarted());
    }catch(e){
      emit(AudioPlayerReady());
    }
  }
  /////////////////////////


  Future<List<String>> getFile() async {
    List<String> files = [];
    List<String> audio = [];
    List<String>error = [];
    error.add("null");
    if (await requstPermission(Permission.storage) &&
        await requstPermission(Permission.accessMediaLocation) &&
        await requstPermission(Permission.manageExternalStorage)) {
      final audioFolder = await getExternalStorageDirectory();
      final audioPath = pp.join(audioFolder!.path, "Audio");
      Directory audioFolderDir = await Directory(audioPath);
      if (!await audioFolderDir.exists()) {
        return error;
      } else {
        var el=0.0;
        var listOfAllFolderAndFiles = await audioFolderDir.list(recursive: true).toList();
        listOfAllFolderAndFiles.forEach((element) {
          audio.add(element.path);
       el=   element.path.length.toDouble();
          //print("mjjjjjjjjjjj");

        });


      }
      return audio;
      //  notifyListeners();

    } else {
      return error;
    }
  }

}

