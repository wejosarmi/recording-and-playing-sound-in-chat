import 'dart:async';

import 'package:audio_session/audio_session.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:flutter_sound/public/flutter_sound_recorder.dart';


import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


import 'package:permission_handler/permission_handler.dart';

import '../manageFiles/filesManager.dart';

import '../utils/customPremission.dart';

part 'recordaudio_state.dart';



class RecordAudioCubit extends Cubit<RecordaudioState> {


  bool _mRecorderIsInited = false;
  final FlutterSoundRecorder _myRecorder = FlutterSoundRecorder();
  final Function()? onRecordStart;
  final Function(String?) onRecordEnd;
  final Function()? onRecordCancel;
  Duration? maxRecordLength;

  ValueNotifier<Duration?> currentDuration = ValueNotifier(Duration.zero);
  StreamSubscription? recorderStream;

  RecordAudioCubit({
    required this.onRecordEnd,
    required this.onRecordStart,
    required this.onRecordCancel,
    required this.maxRecordLength,
  }) : super(RecordAudioReady()) {
    _myRecorder.openRecorder().then((value) {
      _myRecorder.setSubscriptionDuration(const Duration(milliseconds: 200));
      recorderStream = _myRecorder.onProgress!.listen((event) {
        Duration current = event.duration;
        currentDuration.value = current;
        if (maxRecordLength != null) {
          if (current.inMilliseconds >= maxRecordLength!.inMilliseconds) {
            print('[chat_composer] 🔴 Audio passed max length');
            //  stopRecord();
            //    _myRecorder.stopRecorder();
          }
        }
      });
    });
    _openRecorder();
  }
  Future<void> _openRecorder() async {
    var status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      throw RecordingPermissionException('Microphone permission not granted');
    }
    // await _mRecorder!.openRecorder();

    final session = await AudioSession.instance;
    await session.configure(AudioSessionConfiguration(
      avAudioSessionCategory: AVAudioSessionCategory.playAndRecord,
      avAudioSessionCategoryOptions:
          AVAudioSessionCategoryOptions.allowBluetooth |
              AVAudioSessionCategoryOptions.defaultToSpeaker,
      avAudioSessionMode: AVAudioSessionMode.spokenAudio,
      avAudioSessionRouteSharingPolicy:
          AVAudioSessionRouteSharingPolicy.defaultPolicy,
      avAudioSessionSetActiveOptions: AVAudioSessionSetActiveOptions.none,
      androidAudioAttributes: const AndroidAudioAttributes(
        contentType: AndroidAudioContentType.speech,
        flags: AndroidAudioFlags.none,
        usage: AndroidAudioUsage.voiceCommunication,
      ),
      androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
      androidWillPauseWhenDucked: true,
    ));

    _mRecorderIsInited = true;
  }

  void toggleRecord({required bool canRecord}) {
    emit(canRecord ? RecordAudioReady() : RecordAudioClosed());
  }



  List<int> recordedData = [];
  Future<void> startRecord() async {
    try {
//      _myRecorder.stopRecorder();
    } catch (e) {}

    currentDuration.value = Duration.zero;
    try {



      if (await requstPermission(Permission.storage) && await requstPermission(Permission.microphone)&&  await requstPermission(Permission.manageExternalStorage) && await requstPermission(Permission.accessMediaLocation)) {

        var recordingDataController = StreamController<Food>();
        if (onRecordStart != null) onRecordStart!();

        recorderStream = recordingDataController.stream.listen((buffer) {
          if (buffer is FoodData) {
            buffer.data!.forEach((e) => {
              recordedData.add(e)
            });

          }
        });

        //recorderStream!.cancel();

        await _myRecorder.startRecorder(
            toStream: recordingDataController.sink,
            codec: Codec.pcm16,
            bitRate: 8000,
            sampleRate: 16000,
            numChannels: 1);

        emit(RecordAudioStarted());
      }

      // recordingDataController.close();
    } catch (e) {
     /* bool hasStorage = await requstPermission(Permission.storage);
      bool hasMic = await requstPermission(Permission.microphone);
      bool manageExternal = await requstPermission(Permission.manageExternalStorage);
      bool accessMediaLocation = await requstPermission(Permission.accessMediaLocation);*/
      emit(RecordAudioReady());
    }
  }

  void stopRecord() async {
    // timer.cancel();
    try {
      String? result = await _myRecorder.stopRecorder();

      if (result != null) {
        print("[chat_composer] 🟢 Audio path000000000000000:  "+recordedData.length.toString());
      }

      await ManageFiles().saveAudio(recordedData, 16000);
      onRecordEnd(recordedData.toString());
      recordedData=[];

      if (recorderStream != null) {
        await recorderStream!.cancel();

        recorderStream = null;
      }


      emit(RecordAudioReady());
    } finally {
      currentDuration.value = Duration.zero;
    }
    emit(RecordAudioReady());
  }

  void cancelRecord() async {
    try {
      _myRecorder.stopRecorder();
    } catch (e) {}
    emit(RecordAudioReady());
    if (onRecordCancel != null) onRecordCancel!();
    currentDuration.value = Duration.zero;
  }

  @override
  Future<void> close() {
    try {
      _myRecorder.closeRecorder();
    } catch (e) {}
    try {
      // _myRecorder = null;
      // timer.cancel();
    } catch (e) {}
    return super.close();
  }
}

