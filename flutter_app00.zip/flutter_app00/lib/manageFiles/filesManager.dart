import 'dart:io';
import 'dart:typed_data';


import "package:path/path.dart" as pp;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../utils/customPremission.dart';

class ManageFiles  {
  //save file methode
  Future<void> saveAudio(List<int> data, int sampleRate) async {
    final audioFolder = await getExternalStorageDirectory();
    final audioPath = pp.join(audioFolder!.path, "Audio");
    Directory audioFolderDir = await Directory(audioPath);
    if (!await audioFolderDir.exists()) {
      await audioFolderDir.create();
    }
    String path = DateTime.now().millisecondsSinceEpoch.toString() + '.opus';
    final recordedFile = File(pp.join(audioFolderDir.path, path));

    if (await recordedFile.exists()) {
      await recordedFile.delete();
    }

    var channels = 1;
    int byteRate = ((16 * sampleRate * channels) / 8).round();

    var size = data.length;
    double m = byteRate + data.length / 1024;
    double k = m / 1024;
    print(k.round().toString() + " saveFile Straem");
    // var fileSize = size + 36;
    var fileSize = size + 18;

    Uint8List header = Uint8List.fromList([
      // "RIFF"
      82, 73, 70, 70,
      fileSize & 0xff,
      (fileSize >> 8) & 0xff,
      (fileSize >> 16) & 0xff,
      (fileSize >> 24) & 0xff,
      // WAVE
      87, 65, 86, 69,
      // fmt
      102, 109, 116, 32,
      // fmt chunk size 16
      16, 0, 0, 0,
      // Type of format
      1, 0,
      // One channel
      channels, 0,
      // Sample rate
      sampleRate & 0xff,
      (sampleRate >> 8) & 0xff,
      (sampleRate >> 16) & 0xff,
      (sampleRate >> 24) & 0xff,
      // Byte rate
      byteRate & 0xff,
      (byteRate >> 8) & 0xff,
      (byteRate >> 16) & 0xff,
      (byteRate >> 24) & 0xff,
      // Uhm
      ((16 * channels) / 8).round(), 0,
      // bitsize
      16, 0,
      // "data"
      100, 97, 116, 97,
      size & 0xff,
      (size >> 8) & 0xff,
      (size >> 16) & 0xff,
      (size >> 24) & 0xff,
      ...data
    ]);



    return recordedFile.writeAsBytesSync(header, flush: false);
  }//end saveFile methood
  // start getFile Method
  Future<List<String>> getFile() async {
    List<String> files = [];
    List<String> audio = [];
    List<String>error = [];
    error.add("null");
    if (await requstPermission(Permission.storage) &&
        await requstPermission(Permission.accessMediaLocation)
    && await requstPermission(Permission.manageExternalStorage)

    ) {
      final audioFolder = await getExternalStorageDirectory();
      final audioPath = pp.join(audioFolder!.path, "Audio");
      Directory audioFolderDir = await Directory(audioPath);
      if (!await audioFolderDir.exists()) {
        return error;
      } else {

        var listOfAllFolderAndFiles = await audioFolderDir.list(recursive: true).toList();
        listOfAllFolderAndFiles.forEach((element) {

/*if(element.path.isEmpty){
  audio.add("record");
}*/
          audio.add(element.path);


        });


      }
      return audio;


    } else {
      return error;
    }
  }// end getFile Mthode



}
