//import 'package:chat_composer/widgets/message_field.dart';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart' as AP;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


import 'chat_compser.dart';

import 'manageFiles/filesManager.dart';
import 'widgets/customButtonWidget.dart';
import 'widgets/sound_player_widget.dart';

class Chat extends StatefulWidget {
  const Chat({Key? key}) : super(key: key);

  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  List<String> list = ["mdg"];

  TextEditingController con = TextEditingController();

  void setLogOptions() async {
    await AP.Logger.changeLogLevel(AP.LogLevel.NONE);
  }

  @override
  void initState() {
    super.initState();
    setLogOptions();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Column(
            // mainAxisAlignment: MainAxisAlignment.center,
            children: [],
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(
              child: FutureBuilder<List<String>>(
                  future: ManageFiles().getFile(),
                  builder: (context, AsyncSnapshot<List<String>> snapshot) {
                    if (snapshot.connectionState == ConnectionState.done) {
                      return ListView.builder(
                          //reverse: true,
                          itemCount:snapshot.data!=null? snapshot.data!.length:1,
                          itemBuilder: (_, index) {

                            if(snapshot.data!=null){
                            if (snapshot.data!.isEmpty && index != 0) {
                              return Text("snapshot Is Empty");
                            } else {
                              AP.AudioPlayer audio = AP.AudioPlayer(
                                  playerId: "custom_" + index.toString());


                              return Container(
                                margin: EdgeInsets.all(10),
                                child: Column(
                                  children: [
                                    //  Text(snapshot.data![index]),
                                    //     Text(list[index]),

                                    StatefulBuilder(
                                        builder: (context, setInnerState) {
                                      return SoundPlayerWidget(
                                          audioPlayer: audio,
                                          url: snapshot.data![index],
                                          index: index);
                                    })
                                  ],
                                ),
                              );
                            }
                            setState(() {

                            });
                            }else{return Container();}
                          });
                    } else {
                      return Center(child: Container());
                    }
                  }),
            ),
            ChatComposer(
              controller: con,
              onReceiveText: (str) {
                setState(() {
                  list.add('TEXT : ' + str!);
                  print(
                      "1111111111111111111111111111111111111111111111111111111111111111111111");

                  con.text = '';
                });
              },
              /*    onRecordEnd: (p){
                print("STRING IN COMPOSER: "+ p!);
              },*/
              onRecordEnd: (path) {
                setState(() {
                  list.add('TEXT : ' + path!);
                  //  recordEnd = true;
                  print("rrrrrrrrrrrrrrrrr " + path);
                });
              },
              textPadding: EdgeInsets.zero,
              ////////////// emoticonButton
              leading: emoticonButton(),

              actions: [
                attachFileButton(),

                cameraButton(),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
