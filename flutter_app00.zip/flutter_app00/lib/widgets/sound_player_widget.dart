import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

const double BUBBLE_RADIUS_AUDIO = 16;
class SoundPlayerWidget extends StatefulWidget {

final  String url;
final int index;
  double? duration;
  double? position;
  final bool? isLoading;
  final double bubbleRadius;
  final bool isSender;
  final Color color;
  final bool tail;
  final bool sent;
  final bool delivered;
  final bool seen;
  final TextStyle textStyle;
  final AudioPlayer audioPlayer;
  SoundPlayerWidget({
    Key? key,


   required this.audioPlayer,
   required this.url,
    required this.index,
    this.duration,
    this.position,
    this.isLoading,
    this.bubbleRadius = BUBBLE_RADIUS_AUDIO,
    this.isSender = true,
    this.color = Colors.white70,
    this.tail = true,
    this.sent = false,
    this.delivered = false,
    this.seen = false,
    this.textStyle = const TextStyle(
      color: Colors.black87,
      fontSize: 12,
    ),
  }) : super(key: key);

  @override
  State<SoundPlayerWidget> createState() => _SoundPlayerWidgetState();
}

class _SoundPlayerWidgetState extends State<SoundPlayerWidget> {
  bool _isPuas=false;
  bool _play=false;

  Duration nDuration = Duration.zero;
  Duration nPosition = Duration.zero;

  double v = 0.0;
  int fuck = 0;

  void checkCurrentAudio(AudioPlayer curr)async{
    print("========== No Of PLAYERS =============: "+ AudioPlayer.players.length.toString());
    for(AudioPlayer ap in AudioPlayer.players.values){
      if(curr != ap){
        if(ap.state == PlayerState.PLAYING){
          await ap.pause();
        }
      }
    }
  }

  void getDurations()async{
    var du = await widget.audioPlayer.getDuration();
    var du1 = await widget.audioPlayer.playerId;
    print("GET-DURATION=========: "+ du.toString());
    print("GET-PLAYERID=========: "+ du1);
  }
  @override
  void initState() {


    // TODO: implement initState
    super.initState();
    //GetWidget(widget.audioPlayer);
    //getDurations();
  }

  @override
  void dispose() {
    // TODO: implement dispose

    super.dispose();
    /*if(mounted){
      widget.audioPlayer .dispose();
    }*/
  }
  @override
  Widget build(BuildContext context) {
    if(mounted){
      widget.audioPlayer.setReleaseMode(ReleaseMode.RELEASE);
      widget.audioPlayer.onPlayerStateChanged.listen((event) {
        print("EVENT LISTEN STATE: "+ event.name);
        if(event== PlayerState.COMPLETED){
          widget.audioPlayer.release();
          setState(() {
            _play= false;
            _isPuas= false;
            this.nPosition= Duration.zero;
          });
        }
        else if(event == PlayerState.PAUSED){
         // widget.audioPlayer.release();
          setState(() {
            _isPuas= true;
            _play= true;
          });
        }
        else if(event == PlayerState.STOPPED){
          //widget.audioPlayer.release();
          setState(() {
            _isPuas= false;
            _play= false;
            //this.position=0.0;
            this.nPosition= Duration.zero;
          });
        }
        else if(event == PlayerState.PLAYING){
          setState(() {
            _isPuas= false;
            _play= true;
          });
        }
      });

      widget.audioPlayer.onSeekComplete.listen((event) {
        print("********** SEEK COMPLETED of: "+widget.audioPlayer.playerId +" ********************");
      });
      widget.audioPlayer.onAudioPositionChanged.listen((event) {
        print("~~~~~~~~~~~~~ POSITION: "+ event.inSeconds.toString());
        setState(() {
          this.nPosition = event;
          //this.position= event.inSeconds.toDouble();
        });
      });

      widget.audioPlayer.onDurationChanged.listen((event) {
        print("~~~~~~~~~~~~~ DURATION: "+ (event.inMilliseconds.toDouble()/1000.00).ceil() .toString());
        setState(() {
          this.nDuration = event;
          //this.duration = event.inMilliseconds.toDouble();
        });
      });
    }
    bool stateTick = true;
    Icon? stateIcon;
    if (widget.sent) {
      stateTick = true;
      stateIcon = const Icon(
        Icons.done,
        size: 18,
        color: Color(0xFF97AD8E),
      );
    }
    if (widget.delivered) {
      stateTick = true;
      stateIcon = const Icon(
        Icons.done_all,
        size: 18,
        color: Color(0xFF97AD8E),
      );
    }
    if (widget.seen) {
      stateTick = true;
      stateIcon = const Icon(
        Icons.done_all,
        size: 18,
        color: Color(0xFF92DEDA),
      );
    }



    return Container(
      child: Row(
        children: <Widget>[
          widget.isSender
              ? const Expanded(
                  child: SizedBox(
                    width: 5,
                  ),
                )
              : Container(),
          Container(
            color: Colors.transparent,
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * .8,
                maxHeight: 70),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              child: Container(
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(widget.bubbleRadius),
                    topRight: Radius.circular(widget.bubbleRadius),
                    bottomLeft: Radius.circular(widget.tail
                        ? widget.isSender
                            ? widget.bubbleRadius
                            : 0
                        : BUBBLE_RADIUS_AUDIO),
                    bottomRight: Radius.circular(widget.tail
                        ? widget.isSender
                            ? 0
                            : widget.bubbleRadius
                        : BUBBLE_RADIUS_AUDIO),
                  ),
                ),
                child: Column(
                  children: [
                    getAudioWidget(widget.audioPlayer),

                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String audioTimer(final duration, double position) {
    return '${(duration ~/ 60).toInt()}:${(duration % 60).toInt().toString().padLeft(2, '0')}/${position ~/ 60}:${(position % 60).toInt().toString().padLeft(2, '0')}';
  }


  Widget getAudioWidget(AudioPlayer audiop){

    Widget wd= Stack(
      children: [
        Row(
          children: [

            RawMaterialButton(
              onPressed: () async{


                if(_isPuas){

                 await widget.audioPlayer.resume();
                 checkCurrentAudio(widget.audioPlayer);

                }
                else if(_play){

                  await widget.audioPlayer.pause();

                }
                else{
                  checkCurrentAudio(widget.audioPlayer);
                 await widget.audioPlayer.play(widget.url, isLocal: true, stayAwake: true);

                }

              },
              elevation: 1.0,
              fillColor: Colors.white,
              child:
              _play==false
                  ? const Icon(
                Icons.play_arrow,
                //   Icons.pause, ///~~///////////////
                size: 30.0,
              )
                  :   _isPuas==true? const Icon(Icons.play_arrow,
                  size: 30.0, color: Colors.red):const Icon(Icons.pause,
                  size: 30.0, color: Colors.black),
              padding: const EdgeInsets.all(0.0),
              shape: const CircleBorder(),
            ),
            Expanded(
              child: Slider(

                  min: 0,
                  max:this.nDuration.inMilliseconds.toDouble(),

                  value:this.nPosition.inMilliseconds.toDouble(),

                  onChanged: (value) {

                    print("on CHANGE IN SLIDER: "+ value.toString() + "in ms: "+ (value * 1000).toInt().toString());

                    setState(() {
                      if(value<=0.0){
                        widget.audioPlayer.seek(Duration.zero);
                        this.nPosition=Duration.zero;
                      }
                      else if (value < this.nDuration.inMilliseconds.toDouble() && value >0.0){
                        widget.audioPlayer.seek(Duration(milliseconds: value.toInt()));
                        //this.position = value-0.1;
                      }
                      else if(value == this.nDuration.inMilliseconds.toDouble()){
                        widget.audioPlayer.release();
                      }



                    });


                  }) ,

            ),
          ],
        ),
        SizedBox(height: 10,),

        Positioned(
          bottom: 0,
          right: 25,
          child: Container(
            child: Column(
              children: [

                Text(
                  '${audioTimer((this.nDuration.inMilliseconds.toDouble()/1000.00).ceil(),  (this.nPosition.inMilliseconds.toDouble()/1000.00).ceilToDouble())}',
                ),
              ],
            ),
          ),

        ),
        widget.seen != widget.seen
            ? Positioned(
          bottom: 4,
          right: 6,
          child: Icon(Icons.check),
        )
            : SizedBox(
          width: 1,
        )
      ],
    );
    return wd;

  }

  Stream<void> GetWidget(AudioPlayer audiop)async*{
    audiop.onPlayerStateChanged.listen((event) {
      print("PLAYER STATE IN STREAM: "+ event.name);
    });
  }



}

