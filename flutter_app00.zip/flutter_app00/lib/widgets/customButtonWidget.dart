
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Widget emoticonButton() => CupertinoButton(
padding: EdgeInsets.zero,
child: const Icon(
Icons.insert_emoticon_outlined,
size: 25,
color: Colors.black,
),
onPressed: () {},
);
///////////////////////////////////////
Widget attachFileButton()=> CupertinoButton(
padding: EdgeInsets.zero,
child: const Icon(
Icons.attach_file_rounded,
size: 25,
color: Colors.red,
),
onPressed: () {},
);
/////////////////////////////////////
Widget cameraButton()=>
CupertinoButton(
padding: EdgeInsets.zero,
child: const Icon(
Icons.camera_alt_rounded,
size: 25,
color: Colors.blue,
),
onPressed: () {},
);