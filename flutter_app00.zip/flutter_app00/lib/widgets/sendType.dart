

import 'package:flutter/cupertino.dart';

import '../consts/consts.dart';

class SendType extends StatelessWidget {
  final double height;
  final Function()? onTap;
  final IconData? icon;

  const SendType({required this.height, this.onTap, @required this.icon});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap ?? () {},
      child: Container(
        width: height - 8,
        height: height - 8,
        child: Icon(
          icon,
          color: localSendButtonColor,
          size: 28,
        ),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: localSendButtonBackgroundColor,
        ),
      ),
    );
  }
}