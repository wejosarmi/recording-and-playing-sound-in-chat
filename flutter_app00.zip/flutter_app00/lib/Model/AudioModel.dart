import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

class AudioModel{

  final AudioPlayer player;
  Duration _duration = Duration();
  Duration _position = Duration();
  bool _isPlaying = false;
  bool _isResum=false;
  bool _isLoading = false;
  bool _isPause = false;
  int _divistion = 0;

  AudioModel(this.player);

  ValueNotifier<Duration?> currentDuration = ValueNotifier(Duration.zero);
  int get divition => _divistion;
  Duration get duration => _duration;
  Duration get position => _position;
  bool get isResum => _isResum;
  bool get isPlaying => _isPlaying;
  bool get isPause => _isPause;
  bool get isLoading => _isLoading;


}