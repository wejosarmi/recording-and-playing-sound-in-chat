package com.example.flutter_app00

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
